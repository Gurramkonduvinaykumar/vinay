package com.vinay.Bank;

public class Bank {
	int accountNumber;
    String name;
    String accountType;
    double balance;
   
    public int getAccountNumber() {
        return accountNumber;
    }
   
    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }
   
    public String getName() {
        return name;
    }
   
    public void setName(String name) {
        this.name = name;
    }
   
    public String getAccountType() {
        return accountType;
    }
   
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
   
    public void getBalance() {
       
        if( balance <1000)
        {
        try
        {   
            throw new NumberFormatException();
        }
        catch(NumberFormatException a)
        {
            System.out.println("Balance is low"+balance);
        }
        }
    }   
    }
