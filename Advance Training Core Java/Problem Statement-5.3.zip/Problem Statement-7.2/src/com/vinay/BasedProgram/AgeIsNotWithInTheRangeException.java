package com.vinay.BasedProgram;

public class AgeIsNotWithInTheRangeException extends Exception {

}
